package com.javas.db;

import org.springframework.data.jpa.repository.JpaRepository;

import com.javas.model.Book;

public interface BookRepository extends JpaRepository<Book, Long> {
}