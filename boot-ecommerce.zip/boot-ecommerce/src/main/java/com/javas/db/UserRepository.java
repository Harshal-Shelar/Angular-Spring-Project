package com.javas.db;

import org.springframework.data.jpa.repository.JpaRepository;

import com.javas.model.User;

public interface UserRepository extends JpaRepository<User, Long> {
	
}