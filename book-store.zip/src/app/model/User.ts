export class User {
    id: number;
    name: string;
    type: string;  
    password: string; 
    email: string;
    address: string;
    mob: string;
  }

  